<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <a href="cha?id=<?php echo e($v->id); ?>"> <button id="<?php echo e($v->id); ?>" class="cc"> <?php echo e($v->name); ?></button></a>

     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <hr>

<table class="table">
<tbody id="tq">

</tbody>

</table>
</body>
</html>
<script src="/jquery-3.3.1.min.js"></script>
<script>
// $(document).on("click",".cc",function () {
//     id=$(this).attr('id')
//     $.ajax({
//         url:"yu",
//         type:"post",
//         dataType:"json",
//         data:{
//             id:id
//         },
//         success:function (data) {
//               console.log(data)
//              str='';
//              $.each(data,function (k,v) {
//                  str+='<tr>';
//                  str+='<td>'+v.id+'</td>';
//                  str+='<td>'+v.comment+'</td>';
//                  str+='</tr>';
//              })
//
//             $("#tq").html(str);
//
//
//         }
//
//     })
// })
</script>