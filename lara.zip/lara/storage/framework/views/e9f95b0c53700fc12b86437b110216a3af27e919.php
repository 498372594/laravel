<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
</head>
<body>
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<form action="add" enctype="multipart/form-data" method="post">
    <div class="form-group">
        <label for="exampleInputEmail1">商品名称</label>
        <input type="text" class="form-control"  name="shopname">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">商品价格</label>
        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Email" name="price">
    </div>

    <div class="form-group">
        <label for="exampleInputFile">商品图片</label>
        <input type="file" id="exampleInputFile" name="img">
        <p class="help-block">Example block-level help text here.</p>
    </div>
   <div  class="form-group" >
       <label for="exampleInputFile">所属分类</label>
    <select class="form-control" name="uid">
         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($v['id']); ?>"><?php echo e($v['type']); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
   </div>
    <input type="text" name="code">
    <p><img src="<?php echo captcha_src(); ?>" alt="" onclick="this.src='<?php echo e(captcha_src()); ?>'+Math.random()"></p>

    <button type="submit" class="btn btn-default">Submit</button>
</form>
</body>
</html>
