<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
</head>
<body>
<form   action="add" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="exampleInputEmail1">内容</label>
        <input type="text" class="form-control"  name="content">
    </div>
<?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="exampleInputFile">图片</label>
        <input type="file" id="exampleInputFile" name="img">

    </div>

    <button type="submit" class="btn btn-default">Submit</button>
</form>
</body>
</html>