<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <title>Document</title>
</head>
<body>
<div class="list-group">
    <a href="#" class="list-group-item ">

        <p class="list-group-item-text">
            <b>  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <?php echo e($v['zs']['title']); ?>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></b>
        </p>
    </a>
    <input type="hidden" id="cid" value="<?php echo e($id); ?>">
</div>
<ul class="list-group">
    <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item"><?php echo e($v->title); ?></li>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

<a href="" style="text-align: center;margin-left: 435px;">加载更多</a>
</div>
<textarea name="" id="nei" cols="70" rows="10"></textarea>
<button>发布</button>
    
        
          


                  

                    



        
        
        
               
                   
                   
                   
                   
                   
               
        
    



</body>
</html>
<script src="/jquery-3.3.1.min.js"></script>

<script src="/js/bootstrap.js"></script>
<script>
    $(document).on("click",":button",function () {
          zhi=$("#nei").val();
            id=$("#cid").val();
            $.ajax({
                url:"zhan",
                type:"post",
                dataType:"json",
                data:{
                    zhi:zhi,
                    id:id
                },
                success:function (data) {
                    location.href="";
                }
            })
    })
</script>