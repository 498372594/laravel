<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
</head>
<body>


<form action="doo_add" enctype="multipart/form-data" method="post">
    <div class="form-group">
        <input type="hidden" name="id" value="<?php echo e($res[0]['id']); ?>">
        <label for="exampleInputEmail1">商品名称</label>
        <input type="text" class="form-control"  name="shopname" value="<?php echo e($res[0]['shopname']); ?>">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">商品价格</label>
        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Email" name="price" value="<?php echo e($res[0]['price']); ?>">
    </div>

    <div class="form-group">
        <label for="exampleInputFile">商品图片</label>
        <input type="file" id="exampleInputFile" name="img">
        <p class="help-block">Example block-level help text here.</p>
    </div>
    <div  class="form-group" >
        <label for="exampleInputFile">所属分类</label>
        <select class="form-control" name="uid">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($v['id']); ?>"><?php echo e($v['type']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
</form>
</body>
</html>
