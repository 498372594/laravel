<?php
Route::group(['prefix'=>'qht','namespace'=>'qht'],function (){
   Route::get('login','ComController@login')->name('qht.login');
    Route::get('register','ComController@register')->name('qht.register');
    Route::post('doadd','ComController@doadd')->name('qht.doadd');
    Route::post('dologin','ComController@dologin')->name('qht.dologin');
});