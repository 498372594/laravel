<?php
Route::group(['prefix'=>'index','namespace'=>'index'],function (){
   Route::get('index','ComController@index')->name('index.index');
    Route::post('add','ComController@add')->name('index.add');
    Route::get('show','ComController@show')->name('index.show');
    Route::get('info','ComController@info')->name('index.info');
    Route::get('do_show','ComController@do_show')->name('index.do_show');
    Route::post('zhan','ComController@zhan')->name('index.zhan');
    Route::post('show_json','ComController@show_json')->name('index.show_json');
});