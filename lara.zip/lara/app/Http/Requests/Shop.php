<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class Shop extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'shopname'=>'required',
            'price'=>'required',
            'uid'=>'required',
            'code'=>'required|captcha',

        ];
    }

    public function messages(){
        return [
            'shopname.required'=>'商品名称不能为空',
            'price.required'=>'商品价格不能为空',
            'uid.required'=>'商品属性不能为空',
            'code.captcha'=>'验证码不正确',
            'code.required'=>'验证码不能为空',
        ];
}
}
