<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class Yz extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
           'name'=>'required|unique:users,name',
            'email'=>'required|email|between:3,19',
            'password'=>'confirmed',
            'yzm'=>'captcha',
        ];
    }
    function messages(){
       return[
           'name.required'=>'用户不能为空',
            'name.unique'=>'用户已存在',
           'password.confirmed'=>'密码不一致',
           'yzm.captcha'=>'验证码错误'
       ];

    }
}
