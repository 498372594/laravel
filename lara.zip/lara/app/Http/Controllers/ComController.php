<?php

namespace App\Http\Controllers;

use App\Model\Goods;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\Shop;

class ComController extends Controller
{
    function Index(){
        $data=DB::table('category')->get();
        $json=json_encode($data);
        $res=json_decode($json,1);

        return view('admin/index',['data'=>$res]);
    }

    function add(Shop $req){
        $data=$req->only(['shopname','price','uid']);

        $model=new Goods();

        $file=$req->file('img');
        $name=$file->getClientOriginalName();
        $img=$file->move('upload',$name);
        $data['img']=$img;
        $res=$model->doadd($data);
        if($res){
            return redirect('show');
        }


    }
function tqq(){
    $model=new Goods();
    dd($model->sho());
}
    function show(Request $req){


       $data= Goods::paginate(3);
       $res=DB::table('category')->get();
       $js=json_encode($res);
       $json=json_decode($js,1);
        return view('admin/show',['data'=>$data,'res'=>$json]);
    }

    function del(Request $req){
       $id=$req->post('id');

      $res= DB::table('goods')->delete($id);


      if($res){
          echo 1 ;
      }else{
          echo 2;
      }
    }

function tihuan(){


    $model=new Goods();

dd($model->sho()) ;
}
    function do_sear(Request $req){
        $sear=$req->get('sear');
        $re=DB::select("select * from goods where shopname like '%$sear%'");
        echo json_encode($re);
    }

    function show_bian(Request $req){
       $id=$req->get('id');
        $re=DB::select("select * from goods where id='$id'");
        $data=DB::table('category')->get();
        $json=json_encode($data);
        $res=json_decode($json,1);
        $js=json_encode($re);
        $arr=json_decode($js,1);

        return view("admin/show_bian",['res'=>$arr,'data'=>$res]);
    }

    function doo_add(Request $req){
         $res=$req->only(['shopname','price','uid']);
        $id=$req->get('id');

        $arr=DB::table('goods')->where('id','=',$id)->update($res);

        if($arr){
            return redirect('show');
        }
    }

}
