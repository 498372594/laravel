<?php

namespace App\Http\Controllers\Index;

use App\Model\Boke;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class ComController extends Controller
{
   function  index(){
       return view('index.index');
   }

   function add(Request $req){
       $data=$req->post();

       $file=$req->file('img');
       $img=$file->getClientOriginalExtension();
      $tmp=date("YmdHis",time()).".".$img;
      $im=$file->move("upload",$tmp);
       $data['img']=$im;


      $model=new Boke();
     if($model->doadd($data)){
         return redirect()->route('index.show');
     }
   }

   function show(Request $req){
       $model=new Boke();
       $page=$req->post('page')?$req->post('page'):1;
       $sql=DB::table('boke')->get();
       $json=json_encode($sql);
       $size=3;
       $da=json_decode($json,1);
       $count=count($da);
       $end=ceil($count/$size);
       $data=$model->doshow($page);

       if($data){
           return view('index.show',['data'=>$data,'end'=>$end]);
       }
   }
  function show_json(Request $req){
      $model=new Boke();
      $page=$req->post('page')?$req->post('page'):1;
      $sql=DB::table('boke')->get();
      $json=json_encode($sql);
      $size=3;
      $da=json_decode($json,1);
      $count=count($da);
      $end=ceil($count/$size);
      $data=$model->doshow($page);

      if($data){
          return json_encode($data);
      }
  }
   function info(Request $req){
       $id=$req->get('id');
       $model=new Boke();
      $data=$model->cha($id);
       $res=DB::table('xiao')->where('pid','=',"$id")->orderBy('id','desc')->get();

      if($data){
          return view('index/do_show',['data'=>$data,'id'=>$id,'res'=>$res]);
      }



   }

   function zhan(Request $req){
    $id=$req->post('id');
    $cotent=$req->post('zhi');
    $res=DB::insert("insert into xiao(title,pid)values('$cotent','$id')");
    $data=DB::table('xiao')->where('pid','=',"$id")->orderBy('id','desc')->first();
    return $ar=json_encode($data);


   }
}
