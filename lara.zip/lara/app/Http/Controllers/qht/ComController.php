<?php

namespace App\Http\Controllers\qht;

use App\Model\Zc;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Yz;

class ComController extends Controller
{
    function login(){
    return view('qht.login');
    }
    function register(){
        return view('qht.register');
    }

    function doadd(Yz $req){
        $data=$req->all();
        $model=new Zc();
        if($model->add($data)){
            return redirect()->route('qht.login')->with('msg','注册成功，请登录');
        }

    }

    function dologin(Request $req){
        $res=$req->only(['email','password']);
        $model=new Zc();
        dd($model->dolog($res));
    }
}
