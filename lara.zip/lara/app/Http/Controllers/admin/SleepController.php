<?php

namespace App\Http\Controllers\admin;

use App\Model\Info;
use App\Model\Zt;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class SleepController extends Controller
{
    function show_do(){

      $data=DB::table('zt')->get();
        return view('admin/show_do',['data'=>$data ]);
    }

    function cha(Request $req){
        $id=$req->get('id');
        $page=$req->post('page')?$req->post('page'):1;
        $size=3;
        $forset=($page-1)*$size;
        $res=DB::table('info')->get();
        $count=count($res);
       $end=ceil($count/$size);
//        $model=new Zt();
        $data=DB::table('info')->where('pid','=',"$id")->orderBy('id','desc')->offset($forset)->limit($size)->get();
//
//        $ar=$model->ace($id);
//        return json_encode($ar);
       return view('admin/zhan',['data'=>$data,'id'=>$id,'end'=>$end]);

    }

    function add(Request $req){
        $id=$req->post('pid');
        $comment=$req->post('zhi');
//        $res=  DB::insert("insert into info(comment,pid)values('$comment','$id')");

//   return json_encode($re);
                $model=new Info();
   $arr=$model->doadd($id,$comment);
        $re=DB::table('info')->orderBy('id','desc')->first();
 return json_encode($re);



    }


    function show_json(Request $req){
          $id=$req->post('id');
        $page=$req->post('page')?$req->post('page'):1;
        $size=3;
        $forset=($page-1)*$size;
        $res=DB::table('info')->get();
        $count=count($res);

        $data=DB::table('info')->where('pid','=',"$id")->orderBy('id','desc')->offset($forset)->limit($size)->get();
        return json_encode($data);
    }

//    function yu(Request $req){
//        $id=$req->post('id');
//            $model=new Zt();
//        $ar=$model->ace();
//       return json_encode($ar);
//    }
}
