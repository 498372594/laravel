<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Goods extends Model
{
    public $table = 'goods';
    public $timestamps = false;

    function doadd($data)
    {
        $this->shopname = $data['shopname'];
        $this->price = $data['price'];
        $this->img = $data['img'];
        $this->uid = $data['uid'];
        return $this->save();
    }

    function ace(){

   //  return  $this->hasMany(Cate::class,"id",'uid');
//        return $this->belongsToMany(Cate::class,'c_g','g_id','c_id');
       return $this->belongsToMany(Cate::class,'c_g','g_id','c_id');

    }

    function sho(){

     return $this->with(['ace'=>function($query){
     $query->where('c_id',1);
     }])->get()->toArray();


    }



}
