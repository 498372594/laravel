<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Boke extends Model
{
  public   $table="boke";

  function doadd($data){

   $this->content=$data['content'];

  $this->img=$data['img'];
   return $this->save();
  }

  function doshow($page){
      $size=3;
      $forset=($page-1)*$size;

      $data=$this->offset($forset)->limit($size)->get()->toArray();
     return $data;
  }

  function zs(){
    return  $this->hasOne(Bw::class,'pid','id');
  }
  function cha($id){
      return $this->with('zs')->where('id','=',"$id")->get()->toArray();
  }
}
