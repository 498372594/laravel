<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Info extends Model
{
   public $table='info';

   function doadd($id,$comment){
         $data['pid']=$id;
         $data['comment']=$comment;
         $data['created_at']=date('Y-m-d:H:i:s',time());
       $data['updated_at']=date('Y-m-d:H:i:s',time());
       return  $this->insert($data);
//         return $this->save();
//        $id=$data['id'];
//        $comment=$data['zhi'];
//        $data['pid']=$id;
//        $data['comment']=$comment;

//     return  $this->($data);
   }
}
