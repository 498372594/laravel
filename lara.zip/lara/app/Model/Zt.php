<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Zt extends Model
{
    public $table="zt";
    function doshow(){

        return  $this->hasMany(Info::class,'pid',"id");
    }

    function ace(){
       return  $this->with(['doshow'=>function(){

        }])->get()->toArray();
    }
}
