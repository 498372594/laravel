<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as logo;
class Zc extends logo
{
    public  $table='users';
  public $timestamps=false;
    function add($data){
      $this->name=$data['name'];
      $this->email=$data['email'];
      $this->password=bcrypt($data['password']);
    return  $this->save();
    }

    function dolog($res){
        $re=auth()->attempt($res);
        if($re){
            return auth()->user();
        }

    }


}
