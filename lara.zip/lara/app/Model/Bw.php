<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Bw extends Model
{
  public $table="bw";
}
