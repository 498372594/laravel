<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
</head>
<body>
<table class="table">
    <tr>
        <td>浏览列表</td>
        <td></td>
        <td></td>
    </tr>
    <input type="hidden" value="{{$id}}" id="ds">

    <tbody id="tt">
    @foreach($data as $k=>$v)

    <tr>

     <td><input type="checkbox" class="" name="dx" id="{{$v->id}}">{{$v->comment}}</td>
        <td>{{$v->created_at}}</td>
       <td>{{$v->updated_at}}</td>

    </tr>

        @endforeach
        </tbody>



    <td ><a href="#" class="jz">加载更多</a></td>
    <input type="hidden" class="page" value="1">
    <input type="hidden" value="{{$end}}" id="wei">
</table>
<button  class="duo">多删</button>
<table class="table">

    <tr>留言界面</tr>
   {{--<input type="text" class="zhi"></td></tr>--}}
    <tr><td><textarea name="" id="" cols="100" rows="5"  class="zhi"></textarea></td></tr>

    <tr><td><button class="tj" >提交</button></td></tr>
</table>
</body>
</html>
<script src="/jquery-3.3.1.min.js"></script>
<script>
$(document).on("click",".duo",function () {
   arr=document.getElementsByName('dx');
   str='';
console.log(arr);

   for(i=0;i<arr.length;i++){
       if(arr[i].checked==true){
           str+=','+arr[i].id;
       }
       }id=str.substr(1);
    alert(id)

})
    $(document).on("click",".jz",function () {
         shou=$(".page").val();
        id=$("#ds").val();

         end=$("#wei").val();
         tet=$(this).text();
         if(tet=="加载更多"){
             page=parseInt(shou)+1>end?end:parseInt(shou)+1;
         }
        $.ajax({
            url:"show_json",
            type:"post",
            dataType:"json",
            data:{
               page:page,
                id:id
            },
            success:function (data) {

               str='';
               $.each(data,function (k,v) {
                   str+='<tr>';
                   str+='<td>'+v.comment+'</td>';
                   str+='<td>'+v.created_at+'</td>';
                   str+='<td>'+v.updated_at+'</td>';
                   str+='</tr>';
               })
                $("#tt").append(str);
                $(".page").val(page)
               // $(".jz").remove();


            }
        })
    })
$(document).on("click",".tj",function () {
    id=$("#ds").val();
    zhi=$(".zhi").val();
    $.ajax({
        url:"add",
        type:"post",
        dataType:"json",
        data:{
            pid:id,
            zhi:zhi
        },
        success:function (data) {

            str='';
            str+='<tr>';
            str+='<td>'+data.comment+'</td>';
            str+='<td>'+data.created_at+'</td>';
            str+='<td>'+data.updated_at+'</td>';
            str+='</tr>';

            $("tr:eq(1)").before(str)

        }
    })
})
</script>