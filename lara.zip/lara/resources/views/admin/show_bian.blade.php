<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="{{asset('css/bootstrap.css')}}">
</head>
<body>


<form action="doo_add" enctype="multipart/form-data" method="post">
    <div class="form-group">
        <input type="hidden" name="id" value="{{$res[0]['id']}}">
        <label for="exampleInputEmail1">商品名称</label>
        <input type="text" class="form-control"  name="shopname" value="{{$res[0]['shopname']}}">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">商品价格</label>
        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Email" name="price" value="{{$res[0]['price']}}">
    </div>

    <div class="form-group">
        <label for="exampleInputFile">商品图片</label>
        <input type="file" id="exampleInputFile" name="img">
        <p class="help-block">Example block-level help text here.</p>
    </div>
    <div  class="form-group" >
        <label for="exampleInputFile">所属分类</label>
        <select class="form-control" name="uid">
            @foreach($data as $k=>$v)
                <option value="{{$v['id']}}">{{$v['type']}}</option>
            @endforeach
        </select>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
</form>
</body>
</html>
