<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
</head>
<body>
<input type="text" class="sear"><button class="page">搜索</button>

<select  id="sy">
    @foreach($res as $k=>$v)
    <option value="{{$v['id']}}">
        {{$v['type']}}
    </option>
        @endforeach
</select>
<table class="table">
    <tr>
        <td>id</td>
        <td>商品名称</td>
        <td>商品价格</td>
        <td>商品图片</td>
        <td>所属分类</td>
        <td>操作</td>
    </tr>
    <tbody id="tq">
    @foreach($data as $k=>$v)
    <tr>
        <td>{{$v->id}}</td>
        <td>{{$v->shopname}}</td>
        <td>{{$v->price}}</td>
        <td><img src="/{{$v->img}}" alt="" width="100px" height="100px"></td>
        <td>{{$v->uid}}</td>
        <td><a href="#" id="{{$v->id}}" class="sc" >删除</a>|<a href="show_bian?id={{$v->id}}">编辑</a></td>
    </tr>
        @endforeach
    </tbody>
</table>
{!! $data->render() !!}
</body>
</html>
<script src="jquery-3.3.1.min.js"></script>
<script>
    $(document).on("change","#sy",function () {
         id=$(this).val();
         $.ajax({
             url:"tihuan",
             dataType:"json",
             type:"post",
             data:{
                id:id
             },
             success:function (data) {
                 str='';
                 $.each(data,function (k,v) {
                     str+='<tr>';
                     str+='<td>'+v.id+'</td>';
                     str+='<td>'+v.shopname+'</td>';
                     str+='<td>'+v.price+'</td>';
                     str+='<td><img src="/'+v.img+'"  alt="" width="100px" height="100px"></td>';
                     str+='<td>'+v.uid+'</td>';
                     str+='</tr>';
                 })
                 $("#tq").html(str);
             }
         })
    })
    $(document).on("click",".page",function () {
         sear=$(".sear").val();
        $.ajax({
            url:"do_sear",
            dataType:"json",
            type:"post",
            data:{
                sear:sear
            },
            success:function (data) {
               str='';
               $.each(data,function (k,v) {
                   str+='<tr>';
                   str+='<td>'+v.id+'</td>';
                   str+='<td>'+v.shopname+'</td>';
                   str+='<td>'+v.price+'</td>';
                   str+='<td><img src="/'+v.img+'"  alt="" width="100px" height="100px"></td>';
                   str+='<td>'+v.uid+'</td>';
                   str+='</tr>';
               })
                $("#tq").html(str);

            }
        })
    })

$(document).on("click",".sc",function () {
     id=$(this).attr('id');
     that=$(this);
     $.ajax({
         url:"del",
         dataType:"json",
         type:"post",
         data:{
             id:id
         },
         success:function (data) {
           if(data==1){
               location.href="";
           }

         }
     })
})
</script>