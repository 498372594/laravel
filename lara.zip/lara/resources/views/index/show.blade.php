<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    {{--<link rel="stylesheet" href="{{asset('css/app.css')}}">--}}
    {{--<link rel="stylesheet" href="{{asset('bootstrap.css')}}">--}}
</head>
<body>
<table class="table">
    <tbody id="tq">
    @foreach($data as $k=>$v)
<tr>


 <td width="13px"> <img src="../{{$v['img']}}"   alt="" width="100px" height="100px"></td>
    <td width="340px"> {{$v['content']}}  <br>{{$v['created_at']}} </td>
   <td> <a href="info?id={{$v['id']}}">点击查看</a></td>


</tr>
    @endforeach
    </tbody>
        <input type="hidden" id="shou" value="1">
        <input type="hidden" id="wei" value="{{$end}}">

</table>
<a href="#" class="page">首页</a>
<a href="#" class="page">上一页</a>
<a href="#" class="page">下一页</a>
<a href="#" class="page">尾页</a>
</body>
</html>
<script src="../jquery-3.3.1.min.js"></script>
{{--<script src="js/bootstrap.js"></script>--}}
<script>
    $(document).on("click",".page",function () {
         txt=$(this).text();
         shou=$("#shou").val();
         wei=$("#wei").val();
        if(txt=="首页"){
            page=1;
        }else if(txt=="上一页"){
            page=parseInt(shou)-1<1?1:parseInt(shou)-1;
        }else if(txt=="下一页"){
            page=parseInt(shou)+1>wei?wei:parseInt(shou)+1;
        }else if(txt=="尾页"){
            page=wei;
        }
        $.ajax({
            url:"show_json",
            type:"post",
            dataType:"json",
            data:{
                page:page
            },
            success:function (data) {
                str='';
                $.each(data,function (k,v) {
                    str+='<tr>';
                    str+='<td><img src="../'+v['img']+'"   alt="" width="100px" height="100px"></td>';
                    str+='<td  width="+540px+">'+v.content+' <br>'+v.created_at+'</td>';
                    str+='<td>'+'<a href="info?id='+v.id+'">点击查看</a>'+'</td>';
                    str+='</tr>';
                })
                $("#tq").html(str);
                $("#shou").val(page);
            }
        })

    })
</script>
