<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    {{--<link rel="stylesheet" href="{{asset('css/app.css')}}">--}}
    <link rel="stylesheet" href="{{asset('css/bootstrap.css')}}">
    <title>Document</title>
</head>
<body>
<div class="list-group">
    <a href="#" class="list-group-item ">

        <p class="list-group-item-text">
            <b>  @foreach($data as $k=>$v)


            {{$v['zs']['title']}}

            @endforeach</b>
        </p>
    </a>
    <input type="hidden" id="cid" value="{{$id}}">
</div>
<ul class="list-group">
    @foreach($res as $k=>$v)
    <li class="list-group-item">{{$v->title}}</li>

    @endforeach

</ul>

<a href="" style="text-align: center;margin-left: 435px;">加载更多</a>
</div>
<textarea name="" id="nei" cols="70" rows="10"></textarea>
<button>发布</button>
    {{--<div  style="border: 1px solid black;height: 500px;width: 1050px">--}}
        {{--内容介绍：<div style="border: 1px solid black;height: 170px;width: 750px;text-align: center;margin-left: 75px;" >--}}
          {{--<b>  @foreach($data as $k=>$v)--}}


                  {{--{{$v['zs']['title']}}--}}

                    {{--@endforeach</b>--}}



        {{--</div>--}}
        {{--<input type="hidden" id="cid" value="{{$id}}">--}}
        {{--评论区：<div  class="nr" style="border: 1px solid black;height: 250px;width: 850px;text-align: center;margin-left: 35px;">--}}
               {{--<table class="table">--}}
                   {{--@foreach($res as $k=>$v)--}}
                   {{--<tr>--}}
                   {{--<td>     {{$v->title}}</td>--}}
                   {{--</tr>--}}
                   {{--@endforeach--}}
               {{--</table>--}}
        {{--</div>--}}
    {{--<a href="" style="text-align: center;margin-left: 435px;">加载更多</a>--}}
{{--</div>--}}
{{--<textarea name="" id="nei" cols="70" rows="10"></textarea>--}}
{{--<button>发布</button>--}}
</body>
</html>
<script src="/jquery-3.3.1.min.js"></script>

<script src="/js/bootstrap.js"></script>
<script>
    $(document).on("click",":button",function () {
          zhi=$("#nei").val();
            id=$("#cid").val();
            $.ajax({
                url:"zhan",
                type:"post",
                dataType:"json",
                data:{
                    zhi:zhi,
                    id:id
                },
                success:function (data) {
                    console.log(data)
                    location.href="";
                }
            })
    })
</script>